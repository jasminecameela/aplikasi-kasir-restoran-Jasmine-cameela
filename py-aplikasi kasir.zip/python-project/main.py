print("=== APLIKASI KASIR RESTORAN ===")
total = 0
harga = [0, 25000, 15000, 20000, 30000, 18000]

while True:
    print("\n1. Nasi Goreng - Rp25.000")
    print("2. Mie Ayam    - Rp15.000")
    print("3. Ayam Geprek - Rp20.000")
    print("4. Sate Ayam   - Rp30.000")
    print("5. Bakso       - Rp18.000")
    print("0. Selesai Memilih")

    pilihan = int(input("Pilih menu (contoh : 1): "))

    if pilihan == 0:
        break
    elif pilihan > 5:
        print("Menu tidak tersedia!")
        continue

    jumlah = int(input("Jumlah: "))
    total = total + harga[pilihan] * jumlah

if total > 200000:
    diskon = 20
else:
    diskon = 0

potongan = total * diskon / 100

print("\n=== STRUK PEMBAYARAN ===")
print("Total Belanja :", total)
print("Diskon        :", diskon, "%")
print("Potongan      :", potongan)
print("Total Bayar   :", total - potongan)
print("Terima Kasih")
